import { combineReducers } from 'redux';
import kittens from './kittens';

const reducers = combineReducers({
  kittens
});

export default reducers;
